module Main where

import Lib

main :: IO ()
main = someFunc
solution x y = div (x*y) (gcd x y)
